package com.bakery.service;

import com.bakery.model.Order;
import com.bakery.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;

    // 1. READ: Get full order history for an administrator dashboard
    @Transactional(readOnly = true)
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // 2. READ: Get purchase records for a specific logged-in user profile
    @Transactional(readOnly = true)
    public List<Order> getOrdersByUserId(Long userId) {
        // Note: You will need to add "List<Order> findByUserId(Long userId);" to your OrderRepository
        return orderRepository.findByUserId(userId);
    }

    // 3. READ: Look up details for one specific invoice/order
    @Transactional(readOnly = true)
    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
    }

    // 4. UPDATE: Modify status (e.g., PENDING -> BAKING -> DELIVERED)
    @Transactional
    public Order updateOrderStatus(Long orderId, String newStatus) {
        Order order = getOrderById(orderId);
        order.setOrderStatus(newStatus.toUpperCase());
        return orderRepository.save(order);
    }
}