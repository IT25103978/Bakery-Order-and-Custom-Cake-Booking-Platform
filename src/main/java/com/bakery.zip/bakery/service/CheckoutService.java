package com.bakery.service;

import com.bakery.dto.CheckoutRequest;
import com.bakery.dto.PromoUpdateResponse;
import com.bakery.model.*;
import com.bakery.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CheckoutService {

    private final CartService cartService;
    private final PromotionCodeRepository promoRepository;
    private final SavedCardRepository cardRepository;
    private final OrderRepository orderRepository;

    // 1. Calculate discount based on your PromotionCode model structure
    public PromoUpdateResponse calculateDiscount(Long userId, String promoCode) {
        Cart cart = cartService.getOrCreateCart(userId);
        
        double originalTotal = cart.getCartItems().stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();

        if (promoCode == null || promoCode.isBlank()) {
            return new PromoUpdateResponse(originalTotal, 0.0, originalTotal, "No promo code applied.");
        }

        Optional<PromotionCode> promoOpt = promoRepository.findByPromoCodeAndActiveTrue(promoCode);

        if (promoOpt.isPresent()) {
            double percentage = promoOpt.get().getDiscountPercentage();
            double discountAmount = (originalTotal * percentage) / 100;
            double finalTotal = originalTotal - discountAmount;
            return new PromoUpdateResponse(originalTotal, discountAmount, finalTotal, "Promo code applied successfully!");
        }

        return new PromoUpdateResponse(originalTotal, 0.0, originalTotal, "Invalid or inactive promo code.");
    }

    // 2. Process final checkout matching your exact image layout
    @Transactional
    public Order processCheckout(CheckoutRequest request) {
        Cart cart = cartService.getOrCreateCart(request.userId());
        if (cart.getCartItems().isEmpty()) {
            throw new RuntimeException("Cannot checkout an empty cart");
        }

        // Re-verify totals securely on server side
        PromoUpdateResponse totals = calculateDiscount(request.userId(), request.promoCode());

        // Map cart items directly into your structural layout
        List<OrderItem> orderItems = cart.getCartItems().stream()
                .map(item -> OrderItem.builder()
                        .product(item.getProduct())
                        .quantity(item.getQuantity())
                        .unitPrice(item.getProduct().getPrice())
                        .subtotal(item.getProduct().getPrice() * item.getQuantity())
                        .customCakeId(null) // Can be set explicitly later if handling separate custom configurations
                        .build())
                .toList();

        // Build Order record using fields defined in the image
        Order order = Order.builder()
                .user(cart.getUser())
                .orderItems(orderItems)
                .totalPrice(totals.finalTotal()) // Set final reduced price to total_price
                .orderStatus("PENDING")          // Initial confirmation state
                .deliveryAddress(request.deliveryAddress())
                .phoneNumber(request.phoneNumber())
                .build();

        // Handle card vaulting option
        if (request.rememberCard() && request.cardNumber() != null) {
            saveCardDetails(cart.getUser(), request);
        }

        Order savedOrder = orderRepository.save(order);
        
        // Wipe active items from cart upon successful transaction
        cartService.clearCart(request.userId());

        return savedOrder;
    }

    private void saveCardDetails(User user, CheckoutRequest request) {
        String rawNumber = request.cardNumber().replaceAll("\\s+", "");
        String maskedCard = "**** **** **** " + rawNumber.substring(Math.max(0, rawNumber.length() - 4));

        SavedCard card = SavedCard.builder()
                .user(user)
                .cardholderName(request.cardholderName())
                .cardNumber(maskedCard) 
                .expiryDate(request.expiryDate())
                .build();
        cardRepository.save(card);
    }

    @Transactional
    public void deleteSavedCard(Long cardId) {
        cardRepository.deleteById(cardId);
    }

    public List<SavedCard> getSavedCardsForUser(Long userId) {
        return cardRepository.findByUserId(userId);
    }
}