package com.bakery.model;

import lombok.*;
import jakarta.persistence.*;

@Entity
@Table(name = "order_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Long itemId;

    @ManyToOne
    @JoinColumn(name = "product_id") // Nullable if it's a completely custom cake instead
    private Product product;

    @Column(name = "custom_cake_id")
    private Long customCakeId; // Keeps track of custom cake configurations if applicable

    private int quantity;

    @Column(name = "unit_price")
    private double unitPrice;

    private double subtotal; // quantity * unitPrice
}