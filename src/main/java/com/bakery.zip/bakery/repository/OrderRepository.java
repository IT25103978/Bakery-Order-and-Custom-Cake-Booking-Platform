package com.bakery.repository;

import com.bakery.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    
    // Allows looking up full order histories for a specific customer ID
    List<Order> findByUserId(Long userId);
}