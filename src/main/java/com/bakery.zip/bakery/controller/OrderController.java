package com.bakery.controller;

import com.bakery.model.Order;
import com.bakery.service.OrderService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class OrderController {

    private final OrderService orderService;

    // =====================================================
    // CUSTOMER: VIEW OWN ORDER HISTORY
    // GET: /api/orders/my-orders
    // =====================================================
    @GetMapping("/my-orders")
    public ResponseEntity<?> getMyOrders(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Please log in to view your orders.");
        }

        List<Order> userOrders = orderService.getOrdersByUserId(userId);
        return ResponseEntity.ok(userOrders);
    }

    // =====================================================
    // GLOBAL: VIEW SPECIFIC ORDER DETAILS
    // GET: /api/orders/{orderId}
    // =====================================================
    @GetMapping("/{orderId}")
    public ResponseEntity<?> getOrderDetails(@PathVariable Long orderId, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        String userRole = (String) session.getAttribute("userRole");
        
        if (userId == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Access denied.");
        }

        Order order = orderService.getOrderById(orderId);

        // Security boundary: Only allow the owner of the order or an ADMIN to inspect it
        if (!"ADMIN".equals(userRole) && !order.getUser().getId().equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You do not have permission to view this order.");
        }

        return ResponseEntity.ok(order);
    }

    // =====================================================
    // ADMIN: VIEW EVERY ORDER IN THE SYSTEM
    // GET: /api/orders/admin/all
    // =====================================================
    @GetMapping("/admin/all")
    public ResponseEntity<?> getAllOrdersForAdmin(HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("userRole"))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Admin privileges required.");
        }

        List<Order> allOrders = orderService.getAllOrders();
        return ResponseEntity.ok(allOrders);
    }

    // =====================================================
    // ADMIN: CHANGE ORDER STATUS (Baking, Out for Delivery, etc.)
    // PUT: /api/orders/admin/{orderId}/status?status=DELIVERED
    // =====================================================
    @PutMapping("/admin/{orderId}/status")
    public ResponseEntity<?> changeOrderStatus(
            @PathVariable Long orderId,
            @RequestParam String status,
            HttpSession session) {

        if (!"ADMIN".equals(session.getAttribute("userRole"))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Admin privileges required.");
        }

        try {
            Order updatedOrder = orderService.updateOrderStatus(orderId, status);
            return ResponseEntity.ok(updatedOrder);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}